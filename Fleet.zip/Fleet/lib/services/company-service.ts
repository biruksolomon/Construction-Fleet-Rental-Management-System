'use client';

import { apiClient } from '../api-client';

export interface Company {
  id: number;
  name: string;
  businessType: 'CAR_RENTAL' | 'CONSTRUCTION' | 'MIXED';
  currency: string;
  timezone: string;
  language: string;
  status: 'ACTIVE' | 'SUSPENDED';
  address?: string;
  phone?: string;
  email?: string;
  taxId?: string;
  registrationNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PricingRule {
  id: number;
  companyId: number;
  pricingType: 'HOURLY' | 'DAILY' | 'MONTHLY' | 'PROJECT_BASED';
  rate: number;
  overtimeRate?: number;
  currency: string;
  appliesToType: 'VEHICLE' | 'DRIVER' | 'SERVICE';
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CompanySetting {
  id: number;
  companyId: number;
  settingKey: string;
  settingValue: string;
  dataType: 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON';
  createdAt: string;
  updatedAt: string;
}

export interface Client {
  id: number;
  companyId: number;
  name: string;
  email: string;
  phone: string;
  address?: string;
  businessType?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt: string;
}

export interface CompanySubscription {
  id: number;
  companyId: number;
  plan: 'BASIC' | 'STANDARD' | 'PREMIUM' | 'ENTERPRISE';
  status: 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'CANCELLED';
  startDate: string;
  expiryDate: string;
  monthlyCost: number;
  maxVehicles: number;
  maxDrivers: number;
  maxUsers: number;
  autoRenewal: boolean;
  gpsTrackingEnabled: boolean;
  fuelTrackingEnabled: boolean;
  maintenanceTrackingEnabled: boolean;
  payrollIntegrationEnabled: boolean;
  mobileAppEnabled: boolean;
}

export interface CompanyStatistics {
  vehicleCount: number;
  driverCount: number;
  clientCount: number;
  activeRentals: number;
  totalRevenue: number;
  pendingAmount: number;
}

class CompanyService {
  // Company Management
  async getCompany(companyId: number): Promise<Company> {
    return apiClient.get(`/companies/${companyId}`);
  }

  async updateCompany(companyId: number, data: Partial<Company>): Promise<Company> {
    return apiClient.put(`/companies/${companyId}`, data);
  }

  async getAllCompanies(): Promise<Company[]> {
    return apiClient.get('/companies');
  }

  async getCompanyStatus(companyId: number): Promise<Company['status']> {
    const company = await this.getCompany(companyId);
    return company.status;
  }

  async suspendCompany(companyId: number, reason: string): Promise<Company> {
    return apiClient.post(`/companies/${companyId}/suspend`, { reason });
  }

  async activateCompany(companyId: number): Promise<Company> {
    return apiClient.post(`/companies/${companyId}/activate`, {});
  }

  // Settings Management
  async getSetting(companyId: number, key: string): Promise<CompanySetting> {
    return apiClient.get(`/companies/${companyId}/settings/${key}`);
  }

  async getSettings(companyId: number): Promise<CompanySetting[]> {
    return apiClient.get(`/companies/${companyId}/settings`);
  }

  async saveSetting(
    companyId: number,
    key: string,
    value: string,
    dataType: string
  ): Promise<CompanySetting> {
    return apiClient.post(`/companies/${companyId}/settings`, {
      settingKey: key,
      settingValue: value,
      dataType,
    });
  }

  async updateSetting(
    companyId: number,
    key: string,
    value: string
  ): Promise<CompanySetting> {
    return apiClient.put(`/companies/${companyId}/settings/${key}`, {
      settingValue: value,
    });
  }

  async deleteSetting(companyId: number, key: string): Promise<void> {
    return apiClient.delete(`/companies/${companyId}/settings/${key}`);
  }

  // Pricing Rules Management
  async getPricingRules(companyId: number): Promise<PricingRule[]> {
    return apiClient.get(`/companies/${companyId}/pricing-rules`);
  }

  async getActivePricingRules(companyId: number): Promise<PricingRule[]> {
    return apiClient.get(`/companies/${companyId}/pricing-rules/active`);
  }

  async getPricingRulesByType(
    companyId: number,
    type: PricingRule['pricingType']
  ): Promise<PricingRule[]> {
    return apiClient.get(`/companies/${companyId}/pricing-rules/type/${type}`);
  }

  async createPricingRule(companyId: number, rule: Omit<PricingRule, 'id' | 'companyId' | 'createdAt' | 'updatedAt'>): Promise<PricingRule> {
    return apiClient.post(`/companies/${companyId}/pricing-rules`, rule);
  }

  async updatePricingRule(
    companyId: number,
    ruleId: number,
    rule: Partial<PricingRule>
  ): Promise<PricingRule> {
    return apiClient.put(`/companies/${companyId}/pricing-rules/${ruleId}`, rule);
  }

  async deletePricingRule(companyId: number, ruleId: number): Promise<void> {
    return apiClient.delete(`/companies/${companyId}/pricing-rules/${ruleId}`);
  }

  async activatePricingRule(companyId: number, ruleId: number): Promise<PricingRule> {
    return apiClient.post(`/companies/${companyId}/pricing-rules/${ruleId}/activate`, {});
  }

  async deactivatePricingRule(companyId: number, ruleId: number): Promise<PricingRule> {
    return apiClient.post(`/companies/${companyId}/pricing-rules/${ruleId}/deactivate`, {});
  }

  // Client Management
  async getClients(companyId: number): Promise<Client[]> {
    return apiClient.get(`/companies/${companyId}/clients`);
  }

  async getClient(companyId: number, clientId: number): Promise<Client> {
    return apiClient.get(`/companies/${companyId}/clients/${clientId}`);
  }

  async createClient(companyId: number, client: Omit<Client, 'id' | 'companyId' | 'createdAt' | 'updatedAt'>): Promise<Client> {
    return apiClient.post(`/companies/${companyId}/clients`, client);
  }

  async updateClient(companyId: number, clientId: number, client: Partial<Client>): Promise<Client> {
    return apiClient.put(`/companies/${companyId}/clients/${clientId}`, client);
  }

  async deleteClient(companyId: number, clientId: number): Promise<void> {
    return apiClient.delete(`/companies/${companyId}/clients/${clientId}`);
  }

  async searchClients(companyId: number, query: string): Promise<Client[]> {
    return apiClient.get(`/companies/${companyId}/clients/search?q=${query}`);
  }

  // Subscription Management
  async getSubscription(companyId: number): Promise<CompanySubscription> {
    return apiClient.get(`/companies/${companyId}/subscription`);
  }

  async updateSubscription(
    companyId: number,
    subscription: Partial<CompanySubscription>
  ): Promise<CompanySubscription> {
    return apiClient.put(`/companies/${companyId}/subscription`, subscription);
  }

  async renewSubscription(companyId: number): Promise<CompanySubscription> {
    return apiClient.post(`/companies/${companyId}/subscription/renew`, {});
  }

  async cancelSubscription(companyId: number): Promise<void> {
    return apiClient.post(`/companies/${companyId}/subscription/cancel`, {});
  }

  async suspendSubscription(companyId: number): Promise<void> {
    return apiClient.post(`/companies/${companyId}/subscription/suspend`, {});
  }

  // Analytics
  async getStatistics(companyId: number): Promise<CompanyStatistics> {
    return apiClient.get(`/companies/${companyId}/statistics`);
  }

  async getRevenueMetrics(companyId: number, period: string): Promise<any> {
    return apiClient.get(`/companies/${companyId}/revenue-metrics?period=${period}`);
  }
}

export const companyService = new CompanyService();
