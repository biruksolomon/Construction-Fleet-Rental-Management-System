'use client';

import { apiClient } from '../api-client';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  fullName: string;
  companyId: number;
}

export interface AuthenticationResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: string;
  userInfo: UserInfo;
}

export interface UserInfo {
  userId: number;
  email: string;
  fullName: string;
  role: string;
  companyId: number;
}

// NEW: Auth context response - contains complete auth state from backend
export interface AuthContextResponse {
  user: {
    id: number;
    email: string;
    fullName: string;
  };
  company: {
    id: number;
    name: string;
    status: string;
    businessType: string;
    currency: string;
    timezone: string;
    language: string;
  };
  roles: string[];
  permissions: string[];
  features: Record<string, boolean>;
}

export interface VerifyEmailRequest {
  email: string;
  code: string;
}

export interface PasswordResetRequest {
  email: string;
}

export interface ConfirmPasswordResetRequest {
  email: string;
  code: string;
  newPassword: string;
  confirmPassword: string;
}

class AuthService {
  async login(email: string, password: string): Promise<AuthenticationResponse> {
    const response = await apiClient.post<AuthenticationResponse>('/auth/login', {
      email,
      password,
    });
    this.storeAuthData(response);
    return response;
  }

  async register(request: RegisterRequest): Promise<{ message: string }> {
    return apiClient.post('/auth/register', request);
  }

  async verifyEmail(request: VerifyEmailRequest): Promise<AuthenticationResponse> {
    const response = await apiClient.post<AuthenticationResponse>('/auth/verify-email', request);
    this.storeAuthData(response);
    return response;
  }

  async resendVerificationCode(email: string): Promise<{ message: string }> {
    return apiClient.post('/auth/resend-verification', { email });
  }

  async requestPasswordReset(email: string): Promise<{ message: string }> {
    return apiClient.post('/auth/request-password-reset', { email });
  }

  async confirmPasswordReset(request: ConfirmPasswordResetRequest): Promise<{ message: string }> {
    return apiClient.post('/auth/confirm-password-reset', request);
  }

  async resendPasswordResetCode(email: string): Promise<{ message: string }> {
    return apiClient.post('/auth/resend-password-reset', { email });
  }

  async validateResetCode(email: string, code: string): Promise<{ valid: boolean }> {
    return apiClient.post('/auth/validate-reset-code', { email, code });
  }

  async refreshToken(): Promise<AuthenticationResponse> {
    const refreshToken = this.getRefreshToken();
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }

    const response = await apiClient.post<AuthenticationResponse>('/auth/refresh-token', {
      refreshToken,
    });
    this.storeAuthData(response);
    return response;
  }

  async logout(): Promise<void> {
    try {
      await apiClient.post('/auth/logout', {});
    } finally {
      this.clearAuthData();
    }
  }

  async getCurrentUser(): Promise<UserInfo> {
    return apiClient.get('/auth/me');
  }

  async validateToken(): Promise<{ valid: boolean }> {
    return apiClient.post('/auth/validate-token', { refreshToken: this.getRefreshToken() });
  }

  // NEW: Get complete auth context from backend
  // This is the SINGLE SOURCE OF TRUTH for frontend auth state
  async getAuthContext(): Promise<AuthContextResponse> {
    // Ensure token is loaded in API client before making request
    const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;

    if (!token) {
      throw new Error('No access token available');
    }

    // Make sure apiClient has the token set
    apiClient.setToken(token);

    return apiClient.get<AuthContextResponse>('/auth/context');
  }

  private storeAuthData(response: AuthenticationResponse): void {
    if (typeof window !== 'undefined') {
      apiClient.setToken(response.accessToken);
      localStorage.setItem('refreshToken', response.refreshToken);
      localStorage.setItem('user', JSON.stringify(response.userInfo));
    }
  }

  private clearAuthData(): void {
    apiClient.clearToken();
  }

  private getRefreshToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('refreshToken');
    }
    return null;
  }

  getStoredUser(): UserInfo | null {
    if (typeof window !== 'undefined') {
      const user = localStorage.getItem('user');
      return user ? JSON.parse(user) : null;
    }
    return null;
  }

  isAuthenticated(): boolean {
    if (typeof window !== 'undefined') {
      return !!localStorage.getItem('accessToken');
    }
    return false;
  }
}

export const authService = new AuthService();
