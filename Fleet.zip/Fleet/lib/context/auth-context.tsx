'use client';

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { authService, UserInfo, AuthenticationResponse, AuthContextResponse } from '@/lib/services/auth-service';

interface AuthContextType {
  user: UserInfo | null;
  authContext: AuthContextResponse | null; // NEW: Complete auth context from backend
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<AuthenticationResponse>;
  register: (email: string, password: string, fullName: string, companyId: number) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  loadAuthContext: () => Promise<void>; // NEW: Load complete auth context
  isOwnerOrAdmin: () => boolean;
  hasPermission: (permission: string) => boolean; // NEW: Check permission
  hasFeature: (feature: string) => boolean; // NEW: Check feature flag
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [authContext, setAuthContext] = useState<AuthContextResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load complete auth context from backend
  const loadAuthContext = useCallback(async () => {
    try {
      if (authService.isAuthenticated()) {
        const context = await authService.getAuthContext();
        setAuthContext(context);
        return context;
      }
    } catch (error) {
      console.error('Failed to load auth context:', error);
      // Don't logout on context failure - user is authenticated but context failed to load
      // This could be a temporary backend issue
      setAuthContext(null);
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const currentUser = await authService.getCurrentUser();
      setUser(currentUser);
      // Also refresh auth context
      await loadAuthContext();
    } catch (error) {
      console.error('Failed to refresh user:', error);
      await authService.logout();
      setUser(null);
      setAuthContext(null);
    }
  }, [loadAuthContext]);

  useEffect(() => {
    const initAuth = async () => {
      try {
        if (authService.isAuthenticated()) {
          const storedUser = authService.getStoredUser();
          if (storedUser) {
            setUser(storedUser);
          }

          try {
            await authService.validateToken();
            // Load complete auth context on init
            await loadAuthContext();
          } catch (error) {
            try {
              await authService.refreshToken();
              await refreshUser();
            } catch (refreshError) {
              await authService.logout();
              setUser(null);
              setAuthContext(null);
            }
          }
        }
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, [refreshUser, loadAuthContext]);

  const login = async (email: string, password: string) => {
    const response = await authService.login(email, password);
    setUser(response.userInfo);
    return response;
  };

  const register = async (email: string, password: string, fullName: string, companyId: number) => {
    await authService.register({ email, password, fullName, companyId });
  };

  const logout = async () => {
    await authService.logout();
    setUser(null);
  };

  const isOwnerOrAdmin = (): boolean => {
    return user?.role === 'OWNER' || user?.role === 'ADMIN';
  };

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    return authContext?.permissions.includes(permission) ?? false;
  };

  // Check if feature is enabled for company
  const hasFeature = (feature: string): boolean => {
    return authContext?.features[feature] ?? false;
  };

  return (
      <AuthContext.Provider
          value={{
            user,
            authContext,
            isAuthenticated: authService.isAuthenticated(),
            isLoading,
            login,
            register,
            logout,
            refreshUser,
            loadAuthContext,
            isOwnerOrAdmin,
            hasPermission,
            hasFeature,
          }}
      >
        {children}
      </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
