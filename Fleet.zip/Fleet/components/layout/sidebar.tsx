'use client';

import React from "react"

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/context/auth-context';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  LayoutDashboard,
  Users,
  Truck,
  DollarSign,
  Settings,
  CreditCard,
  LogOut,
  Menu,
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  requiredRole?: string[];
}

const NAV_ITEMS: NavItem[] = [
  {
    label: 'Dashboard',
    href: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
  },
  {
    label: 'Clients',
    href: '/dashboard/clients',
    icon: <Users className="h-5 w-5" />,
  },
  {
    label: 'Pricing Rules',
    href: '/dashboard/pricing',
    icon: <DollarSign className="h-5 w-5" />,
    requiredRole: ['OWNER', 'ADMIN'],
  },
  {
    label: 'Subscription',
    href: '/dashboard/subscription',
    icon: <CreditCard className="h-5 w-5" />,
    requiredRole: ['OWNER', 'ADMIN'],
  },
  {
    label: 'Settings',
    href: '/dashboard/settings',
    icon: <Settings className="h-5 w-5" />,
    requiredRole: ['OWNER', 'ADMIN'],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const { company, user, logout } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  const canAccessItem = (item: NavItem): boolean => {
    if (!item.requiredRole) return true;
    return user?.role ? item.requiredRole.includes(user.role) : false;
  };

  return (
    <aside
      className={cn(
        'flex flex-col bg-slate-800 border-r border-slate-700 transition-all duration-300',
        isCollapsed ? 'w-20' : 'w-64'
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-slate-700">
        {!isCollapsed && (
          <div className="flex items-center gap-2 flex-1">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <Truck className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-white text-sm">Fleet</span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1.5 hover:bg-slate-700 rounded-lg text-slate-400 transition-colors"
        >
          {isCollapsed ? (
            <ChevronRight className="h-5 w-5" />
          ) : (
            <ChevronLeft className="h-5 w-5" />
          )}
        </button>
      </div>

      {/* Company Info */}
      {!isCollapsed && company && (
        <div className="px-4 py-4 border-b border-slate-700">
          <p className="text-xs text-slate-500 uppercase tracking-wider">Company</p>
          <p className="text-sm font-semibold text-white truncate">{company.name}</p>
          <p className="text-xs text-slate-400 mt-1">{company.businessType}</p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-6 space-y-2 overflow-y-auto">
        {NAV_ITEMS.filter(canAccessItem).map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');

          return (
            <Link
              key={item.href}
              href={item.href}
              title={isCollapsed ? item.label : undefined}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium text-sm transition-colors whitespace-nowrap',
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:bg-slate-700 hover:text-white'
              )}
            >
              {item.icon}
              {!isCollapsed && item.label}
            </Link>
          );
        })}
      </nav>

      {/* User Info & Logout */}
      <div className="px-3 py-4 border-t border-slate-700 space-y-3">
        {!isCollapsed && user && (
          <div>
            <p className="text-xs text-slate-500 uppercase tracking-wider">User</p>
            <p className="text-sm font-semibold text-white truncate">{user.firstName} {user.lastName}</p>
            <p className="text-xs text-slate-400">{user.role}</p>
          </div>
        )}

        <button
          onClick={handleLogout}
          className={cn(
            'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium text-sm text-red-400 hover:bg-red-900/20 transition-colors',
            isCollapsed ? 'justify-center' : ''
          )}
          title={isCollapsed ? 'Logout' : undefined}
        >
          <LogOut className="h-5 w-5" />
          {!isCollapsed && 'Logout'}
        </button>
      </div>
    </aside>
  );
}
