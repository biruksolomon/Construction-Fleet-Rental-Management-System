'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/context/auth-context';
import { companyService, Company, CompanySetting } from '@/lib/services/company-service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { CheckCircle, AlertCircle } from 'lucide-react';

export default function SettingsPage() {
  const { company, user } = useAuth();
  const [companyData, setCompanyData] = useState<Company | null>(null);
  const [settings, setSettings] = useState<CompanySetting[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!company?.id) return;

      try {
        setIsLoading(true);
        const [companyInfo, settingsData] = await Promise.all([
          companyService.getCompany(company.id),
          companyService.getSettings(company.id),
        ]);
        setCompanyData(companyInfo);
        setSettings(settingsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load settings');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [company?.id]);

  const handleCompanyUpdate = async (field: keyof Company, value: any) => {
    if (!company?.id || !companyData) return;

    try {
      setIsSaving(true);
      setError(null);
      const updated = await companyService.updateCompany(company.id, {
        [field]: value,
      });
      setCompanyData(updated);
      setSuccess('Company updated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update company');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSettingUpdate = async (settingKey: string, value: string) => {
    if (!company?.id) return;

    try {
      setIsSaving(true);
      setError(null);
      await companyService.updateSetting(company.id, settingKey, value);
      setSettings((prev) =>
        prev.map((s) => (s.settingKey === settingKey ? { ...s, settingValue: value } : s))
      );
      setSuccess('Setting updated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update setting');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Spinner className="h-8 w-8 mx-auto mb-4" />
          <p className="text-slate-300">Loading settings...</p>
        </div>
      </div>
    );
  }

  if (!companyData) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Failed to load company settings</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Settings</h1>
        <p className="text-slate-400">Manage your company and account settings</p>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-800">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-red-200">{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-900/20 border-green-800">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertDescription className="text-green-200">{success}</AlertDescription>
        </Alert>
      )}

      {/* Tabs */}
      <Tabs defaultValue="company" className="space-y-6">
        <TabsList className="bg-slate-800 border-slate-700">
          <TabsTrigger value="company" className="text-slate-300 data-[state=active]:text-white">
            Company
          </TabsTrigger>
          <TabsTrigger value="general" className="text-slate-300 data-[state=active]:text-white">
            General
          </TabsTrigger>
          <TabsTrigger value="features" className="text-slate-300 data-[state=active]:text-white">
            Features
          </TabsTrigger>
        </TabsList>

        {/* Company Tab */}
        <TabsContent value="company" className="space-y-6">
          <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Company Information</h2>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-slate-200">
                    Company Name
                  </Label>
                  <Input
                    id="name"
                    value={companyData.name}
                    onChange={(e) => handleCompanyUpdate('name', e.target.value)}
                    disabled={isSaving}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-200">
                    Email
                  </Label>
                  <Input
                    id="email"
                    value={companyData.email || ''}
                    onChange={(e) => handleCompanyUpdate('email', e.target.value)}
                    disabled={isSaving}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-slate-200">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    value={companyData.phone || ''}
                    onChange={(e) => handleCompanyUpdate('phone', e.target.value)}
                    disabled={isSaving}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency" className="text-slate-200">
                    Currency
                  </Label>
                  <Input
                    id="currency"
                    value={companyData.currency}
                    onChange={(e) => handleCompanyUpdate('currency', e.target.value)}
                    disabled={isSaving}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-slate-200">
                  Address
                </Label>
                <Input
                  id="address"
                  value={companyData.address || ''}
                  onChange={(e) => handleCompanyUpdate('address', e.target.value)}
                  disabled={isSaving}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>

              <Button
                onClick={() => setSuccess('Changes saved')}
                disabled={isSaving}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isSaving ? (
                  <>
                    <Spinner className="mr-2 h-4 w-4" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </Button>
            </div>
          </Card>
        </TabsContent>

        {/* General Tab */}
        <TabsContent value="general" className="space-y-6">
          <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">General Settings</h2>

            <div className="space-y-6">
              {settings
                .filter((s) => ['timezone', 'language'].includes(s.settingKey))
                .map((setting) => (
                  <div key={setting.id} className="space-y-2">
                    <Label className="text-slate-200 capitalize">{setting.settingKey}</Label>
                    <Input
                      value={setting.settingValue}
                      onChange={(e) => handleSettingUpdate(setting.settingKey, e.target.value)}
                      disabled={isSaving}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                  </div>
                ))}

              <Button
                onClick={() => setSuccess('Settings saved')}
                disabled={isSaving}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isSaving ? (
                  <>
                    <Spinner className="mr-2 h-4 w-4" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </Button>
            </div>
          </Card>
        </TabsContent>

        {/* Features Tab */}
        <TabsContent value="features" className="space-y-6">
          <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Feature Settings</h2>
            <p className="text-slate-400 mb-6">Manage feature availability for your company</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {['gpsTracking', 'fuelTracking', 'maintenance', 'payroll', 'mobile'].map((feature) => (
                <div key={feature} className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id={feature}
                    defaultChecked
                    className="rounded border-slate-600 bg-slate-700 text-blue-600"
                  />
                  <label htmlFor={feature} className="text-slate-300 capitalize cursor-pointer flex-1">
                    {feature.replace(/([A-Z])/g, ' $1').trim()}
                  </label>
                </div>
              ))}
            </div>

            <Button className="mt-6 bg-blue-600 hover:bg-blue-700 text-white">
              Save Feature Settings
            </Button>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
