'use client';

import React from "react"

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/context/auth-context';
import { companyService, CompanyStatistics } from '@/lib/services/company-service';
import { Card } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { Users, Truck, AlertCircle, TrendingUp } from 'lucide-react';

interface StatCard {
  label: string;
  value: number | string;
  icon: React.ReactNode;
  color: string;
}

export default function DashboardPage() {
  const { company, user } = useAuth();
  const [statistics, setStatistics] = useState<CompanyStatistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatistics = async () => {
      if (!company?.id) return;

      try {
        setIsLoading(true);
        const stats = await companyService.getStatistics(company.id);
        setStatistics(stats);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load statistics');
      } finally {
        setIsLoading(false);
      }
    };

    fetchStatistics();
  }, [company?.id]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Spinner className="h-8 w-8 mx-auto mb-4" />
          <p className="text-slate-300">Loading statistics...</p>
        </div>
      </div>
    );
  }

  const statCards: StatCard[] = [
    {
      label: 'Total Vehicles',
      value: statistics?.vehicleCount || 0,
      icon: <Truck className="h-6 w-6" />,
      color: 'from-blue-500 to-blue-600',
    },
    {
      label: 'Active Drivers',
      value: statistics?.driverCount || 0,
      icon: <Users className="h-6 w-6" />,
      color: 'from-purple-500 to-purple-600',
    },
    {
      label: 'Total Clients',
      value: statistics?.clientCount || 0,
      icon: <Users className="h-6 w-6" />,
      color: 'from-green-500 to-green-600',
    },
    {
      label: 'Active Rentals',
      value: statistics?.activeRentals || 0,
      icon: <TrendingUp className="h-6 w-6" />,
      color: 'from-orange-500 to-orange-600',
    },
  ];

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">Welcome back, {user?.firstName}!</h1>
        <p className="text-slate-400">{company?.name}</p>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="bg-red-900/20 border border-red-800 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-200 font-medium">Error loading statistics</p>
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        </div>
      )}

      {/* Statistics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <Card key={index} className="border-slate-700 bg-slate-800/50 backdrop-blur-xl overflow-hidden">
            <div className={`h-2 bg-gradient-to-r ${stat.color}`} />
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-slate-400 text-sm font-medium">{stat.label}</p>
                <div className="text-slate-500">{stat.icon}</div>
              </div>
              <p className="text-3xl font-bold text-white">{stat.value}</p>
            </div>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <a href="/dashboard/vehicles" className="block p-3 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white transition-colors">
              Manage Vehicles
            </a>
            <a href="/dashboard/drivers" className="block p-3 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white transition-colors">
              Manage Drivers
            </a>
            <a href="/dashboard/clients" className="block p-3 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white transition-colors">
              View Clients
            </a>
          </div>
        </Card>

        <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4">Company Info</h2>
          <div className="space-y-3 text-slate-300 text-sm">
            <div>
              <p className="text-slate-400">Business Type</p>
              <p className="font-medium text-white">{company?.businessType}</p>
            </div>
            <div>
              <p className="text-slate-400">Currency</p>
              <p className="font-medium text-white">{company?.currency}</p>
            </div>
            <div>
              <p className="text-slate-400">Timezone</p>
              <p className="font-medium text-white">{company?.timezone}</p>
            </div>
            <div>
              <p className="text-slate-400">Status</p>
              <p className={`font-medium ${company?.status === 'ACTIVE' ? 'text-green-400' : 'text-red-400'}`}>
                {company?.status}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
