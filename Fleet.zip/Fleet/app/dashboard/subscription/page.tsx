'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/context/auth-context';
import { companyService, CompanySubscription } from '@/lib/services/company-service';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { AlertCircle, CheckCircle, AlertTriangle, RefreshCw, X } from 'lucide-react';

const PLAN_FEATURES = {
  BASIC: {
    vehicles: 10,
    drivers: 5,
    users: 3,
    features: ['GPS Tracking', 'Fuel Tracking'],
  },
  STANDARD: {
    vehicles: 50,
    drivers: 25,
    users: 10,
    features: ['GPS Tracking', 'Fuel Tracking', 'Maintenance Tracking', 'Mobile App'],
  },
  PREMIUM: {
    vehicles: 200,
    drivers: 100,
    users: 50,
    features: ['All Standard Features', 'Payroll Integration', 'Priority Support'],
  },
  ENTERPRISE: {
    vehicles: Infinity,
    drivers: Infinity,
    users: Infinity,
    features: ['All Features', 'Dedicated Support', 'Custom Integration'],
  },
};

export default function SubscriptionPage() {
  const { company } = useAuth();
  const [subscription, setSubscription] = useState<CompanySubscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchSubscription();
  }, [company?.id]);

  const fetchSubscription = async () => {
    if (!company?.id) return;

    try {
      setIsLoading(true);
      const data = await companyService.getSubscription(company.id);
      setSubscription(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load subscription');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRenew = async () => {
    if (!company?.id) return;

    try {
      setIsUpdating(true);
      await companyService.renewSubscription(company.id);
      setSuccess('Subscription renewed successfully');
      fetchSubscription();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to renew subscription');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleCancel = async () => {
    if (!company?.id) return;

    if (!confirm('Are you sure you want to cancel your subscription? This action cannot be undone.')) {
      return;
    }

    try {
      setIsUpdating(true);
      await companyService.cancelSubscription(company.id);
      setSuccess('Subscription cancelled');
      fetchSubscription();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to cancel subscription');
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Spinner className="h-8 w-8 mx-auto mb-4" />
          <p className="text-slate-300">Loading subscription...</p>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Failed to load subscription details</AlertDescription>
        </Alert>
      </div>
    );
  }

  const daysUntilExpiry = Math.ceil(
    (new Date(subscription.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );

  const planFeatures = PLAN_FEATURES[subscription.plan];

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Subscription</h1>
        <p className="text-slate-400">Manage your Fleet Manager subscription plan</p>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-800">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-red-200">{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-900/20 border-green-800">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertDescription className="text-green-200">{success}</AlertDescription>
        </Alert>
      )}

      {/* Current Plan Card */}
      <Card className="border-slate-700 bg-gradient-to-br from-slate-800 to-slate-900 backdrop-blur-xl overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-blue-500 to-purple-500" />
        <div className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Plan Info */}
            <div>
              <p className="text-slate-400 text-sm mb-2">Current Plan</p>
              <h2 className="text-3xl font-bold text-white mb-4">{subscription.plan}</h2>
              <p className="text-slate-300 text-sm mb-1">
                ${subscription.monthlyCost}/month
              </p>
              <p className="text-slate-400 text-xs">
                {subscription.autoRenewal ? 'Auto-renews' : 'Manual renewal'}
              </p>
            </div>

            {/* Status */}
            <div className="flex flex-col justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-2">Status</p>
                <div className="flex items-center gap-2 mb-6">
                  {subscription.status === 'ACTIVE' ? (
                    <>
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-green-400 font-medium">Active</span>
                    </>
                  ) : subscription.status === 'SUSPENDED' ? (
                    <>
                      <AlertTriangle className="h-5 w-5 text-yellow-500" />
                      <span className="text-yellow-400 font-medium">Suspended</span>
                    </>
                  ) : (
                    <>
                      <X className="h-5 w-5 text-red-500" />
                      <span className="text-red-400 font-medium">{subscription.status}</span>
                    </>
                  )}
                </div>
              </div>

              {subscription.status === 'ACTIVE' && (
                <div>
                  <p className="text-slate-400 text-sm mb-1">Expires in</p>
                  <p className="text-white font-bold text-lg">
                    {daysUntilExpiry > 0 ? `${daysUntilExpiry} days` : 'Expired'}
                  </p>
                </div>
              )}
            </div>

            {/* Dates */}
            <div>
              <p className="text-slate-400 text-sm mb-4">Timeline</p>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-slate-500">Start Date</p>
                  <p className="text-white">
                    {new Date(subscription.startDate).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-slate-500">Expiry Date</p>
                  <p className="text-white">
                    {new Date(subscription.expiryDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mt-8">
            {subscription.status === 'ACTIVE' && daysUntilExpiry <= 30 && (
              <Button
                onClick={handleRenew}
                disabled={isUpdating}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                {isUpdating ? 'Renewing...' : 'Renew Now'}
              </Button>
            )}

            {subscription.status !== 'CANCELLED' && (
              <Button
                onClick={handleCancel}
                disabled={isUpdating}
                variant="destructive"
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Cancel Subscription
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Plan Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Limits */}
        <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
          <h3 className="text-lg font-bold text-white mb-6">Usage Limits</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Maximum Vehicles</span>
              <span className="text-white font-semibold">
                {subscription.maxVehicles === 9999 ? 'Unlimited' : subscription.maxVehicles}
              </span>
            </div>
            <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
                style={{
                  width: Math.min(
                    (100 * (subscription.maxVehicles === 9999 ? 100 : 0)) / subscription.maxVehicles,
                    100
                  ) + '%',
                }}
              />
            </div>

            <div className="flex items-center justify-between mt-4">
              <span className="text-slate-300">Maximum Drivers</span>
              <span className="text-white font-semibold">
                {subscription.maxDrivers === 9999 ? 'Unlimited' : subscription.maxDrivers}
              </span>
            </div>

            <div className="flex items-center justify-between mt-4">
              <span className="text-slate-300">Maximum Users</span>
              <span className="text-white font-semibold">
                {subscription.maxUsers === 9999 ? 'Unlimited' : subscription.maxUsers}
              </span>
            </div>
          </div>
        </Card>

        {/* Features */}
        <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl p-6">
          <h3 className="text-lg font-bold text-white mb-6">Included Features</h3>
          <div className="space-y-3">
            {[
              { name: 'GPS Tracking', enabled: subscription.gpsTrackingEnabled },
              { name: 'Fuel Tracking', enabled: subscription.fuelTrackingEnabled },
              { name: 'Maintenance Tracking', enabled: subscription.maintenanceTrackingEnabled },
              { name: 'Payroll Integration', enabled: subscription.payrollIntegrationEnabled },
              { name: 'Mobile App', enabled: subscription.mobileAppEnabled },
            ].map((feature) => (
              <div key={feature.name} className="flex items-center gap-3">
                {feature.enabled ? (
                  <>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span className="text-slate-300">{feature.name}</span>
                  </>
                ) : (
                  <>
                    <X className="h-5 w-5 text-slate-500" />
                    <span className="text-slate-500">{feature.name}</span>
                  </>
                )}
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Info Card */}
      <Card className="border-slate-700 bg-blue-900/20 backdrop-blur-xl p-6">
        <p className="text-blue-200">
          To upgrade your plan or need support? Contact our sales team at sales@fleetmanager.com
        </p>
      </Card>
    </div>
  );
}
