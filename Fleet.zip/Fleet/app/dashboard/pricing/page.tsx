'use client';

import React from "react"

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/context/auth-context';
import { companyService, PricingRule } from '@/lib/services/company-service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { AlertCircle, Plus, Edit, Trash2 } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const PRICING_TYPES = ['HOURLY', 'DAILY', 'MONTHLY', 'PROJECT_BASED'];
const APPLIES_TO_TYPES = ['VEHICLE', 'DRIVER', 'SERVICE'];

export default function PricingPage() {
  const { company } = useAuth();
  const [rules, setRules] = useState<PricingRule[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<PricingRule | null>(null);
  const [formData, setFormData] = useState({
    pricingType: 'HOURLY',
    rate: '',
    overtimeRate: '',
    currency: 'USD',
    appliesToType: 'VEHICLE',
  });

  useEffect(() => {
    fetchRules();
  }, [company?.id]);

  const fetchRules = async () => {
    if (!company?.id) return;

    try {
      setIsLoading(true);
      const data = await companyService.getPricingRules(company.id);
      setRules(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load pricing rules');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!company?.id) return;

    try {
      setIsSaving(true);
      const ruleData = {
        pricingType: formData.pricingType as PricingRule['pricingType'],
        rate: parseFloat(formData.rate),
        overtimeRate: formData.overtimeRate ? parseFloat(formData.overtimeRate) : undefined,
        currency: formData.currency,
        appliesToType: formData.appliesToType as PricingRule['appliesToType'],
        active: true,
      };

      if (editingRule) {
        await companyService.updatePricingRule(company.id, editingRule.id, ruleData);
        setRules((prev) =>
          prev.map((r) => (r.id === editingRule.id ? { ...r, ...ruleData } : r))
        );
      } else {
        const newRule = await companyService.createPricingRule(company.id, ruleData);
        setRules((prev) => [...prev, newRule]);
      }
      resetForm();
      setIsDialogOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save pricing rule');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (ruleId: number) => {
    if (!company?.id) return;

    if (!confirm('Are you sure you want to delete this pricing rule?')) return;

    try {
      await companyService.deletePricingRule(company.id, ruleId);
      setRules((prev) => prev.filter((r) => r.id !== ruleId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete pricing rule');
    }
  };

  const handleToggleActive = async (rule: PricingRule) => {
    if (!company?.id) return;

    try {
      if (rule.active) {
        await companyService.deactivatePricingRule(company.id, rule.id);
      } else {
        await companyService.activatePricingRule(company.id, rule.id);
      }
      setRules((prev) =>
        prev.map((r) => (r.id === rule.id ? { ...r, active: !r.active } : r))
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update pricing rule');
    }
  };

  const handleEdit = (rule: PricingRule) => {
    setEditingRule(rule);
    setFormData({
      pricingType: rule.pricingType,
      rate: rule.rate.toString(),
      overtimeRate: rule.overtimeRate?.toString() || '',
      currency: rule.currency,
      appliesToType: rule.appliesToType,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingRule(null);
    setFormData({
      pricingType: 'HOURLY',
      rate: '',
      overtimeRate: '',
      currency: 'USD',
      appliesToType: 'VEHICLE',
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Spinner className="h-8 w-8 mx-auto mb-4" />
          <p className="text-slate-300">Loading pricing rules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Pricing Rules</h1>
          <p className="text-slate-400">Manage your pricing structure</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Rule
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">{editingRule ? 'Edit Rule' : 'Create Pricing Rule'}</DialogTitle>
              <DialogDescription>
                {editingRule ? 'Update pricing rule details' : 'Create a new pricing rule for your services'}
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-200">Pricing Type</Label>
                  <Select value={formData.pricingType} onValueChange={(value) => setFormData({ ...formData, pricingType: value })}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {PRICING_TYPES.map((type) => (
                        <SelectItem key={type} value={type} className="text-white">
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-200">Applies To</Label>
                  <Select value={formData.appliesToType} onValueChange={(value) => setFormData({ ...formData, appliesToType: value })}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {APPLIES_TO_TYPES.map((type) => (
                        <SelectItem key={type} value={type} className="text-white">
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-200">Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.rate}
                    onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
                    required
                    className="bg-slate-700/50 border-slate-600 text-white"
                    placeholder="0.00"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-200">Overtime Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.overtimeRate}
                    onChange={(e) => setFormData({ ...formData, overtimeRate: e.target.value })}
                    className="bg-slate-700/50 border-slate-600 text-white"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-slate-200">Currency</Label>
                <Input
                  value={formData.currency}
                  onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isSaving ? 'Saving...' : 'Save Rule'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1 border-slate-600 text-slate-200"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-800">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-red-200">{error}</AlertDescription>
        </Alert>
      )}

      {/* Table */}
      <Card className="border-slate-700 bg-slate-800/50 backdrop-blur-xl overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-700/50 border-slate-700">
            <TableRow>
              <TableHead className="text-slate-300">Type</TableHead>
              <TableHead className="text-slate-300">Applies To</TableHead>
              <TableHead className="text-slate-300">Rate</TableHead>
              <TableHead className="text-slate-300">Overtime Rate</TableHead>
              <TableHead className="text-slate-300">Currency</TableHead>
              <TableHead className="text-slate-300">Status</TableHead>
              <TableHead className="text-slate-300 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rules.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-400 py-8">
                  No pricing rules found
                </TableCell>
              </TableRow>
            ) : (
              rules.map((rule) => (
                <TableRow key={rule.id} className="border-slate-700 hover:bg-slate-700/30">
                  <TableCell className="text-white font-medium">{rule.pricingType}</TableCell>
                  <TableCell className="text-slate-300">{rule.appliesToType}</TableCell>
                  <TableCell className="text-slate-300">{rule.rate}</TableCell>
                  <TableCell className="text-slate-300">{rule.overtimeRate || '-'}</TableCell>
                  <TableCell className="text-slate-300">{rule.currency}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium cursor-pointer ${
                        rule.active
                          ? 'bg-green-900/20 text-green-400'
                          : 'bg-red-900/20 text-red-400'
                      }`}
                      onClick={() => handleToggleActive(rule)}
                    >
                      {rule.active ? 'Active' : 'Inactive'}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(rule)}
                        className="text-blue-400 hover:bg-blue-900/20"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(rule.id)}
                        className="text-red-400 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
