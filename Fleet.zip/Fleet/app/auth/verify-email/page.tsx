'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/context/auth-context';
import { authService } from '@/lib/services/auth-service';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { AlertCircle, CheckCircle, Mail } from 'lucide-react';
import { InputOTP } from '@/components/ui/input-otp';

export default function VerifyEmailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { refreshUser } = useAuth();
  const email = searchParams.get('email') || '';

  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [canResend, setCanResend] = useState(true);
  const [resendCountdown, setResendCountdown] = useState(0);

  useEffect(() => {
    if (resendCountdown > 0) {
      const timer = setTimeout(() => setResendCountdown(resendCountdown - 1), 1000);
      return () => clearTimeout(timer);
    }
    setCanResend(true);
  }, [resendCountdown]);

  const handleVerifyEmail = async () => {
    if (code.length !== 6) {
      setError('Please enter a valid 6-digit code');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      await authService.verifyEmail({ email, code });
      setSuccess(true);
      await refreshUser();

      // Redirect to dashboard after 2 seconds
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed. Please try again.');
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    if (!canResend) return;

    setIsResending(true);
    setError(null);

    try {
      await authService.resendVerificationCode(email);
      setCanResend(false);
      setResendCountdown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resend code. Please try again.');
    } finally {
      setIsResending(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <Card className="border border-slate-700 bg-slate-800/50 backdrop-blur-xl shadow-2xl max-w-md w-full">
          <div className="p-8 text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Email Verified!</h2>
            <p className="text-slate-400">Your account is now active. Redirecting to dashboard...</p>
            <div className="flex justify-center mt-6">
              <Spinner className="h-4 w-4" />
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="border border-slate-700 bg-slate-800/50 backdrop-blur-xl shadow-2xl">
          <div className="p-8">
            {/* Header */}
            <div className="mb-8 text-center">
              <div className="flex justify-center mb-4">
                <Mail className="h-12 w-12 text-blue-400" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">Verify Email</h1>
              <p className="text-slate-400">
                We sent a code to <span className="text-white font-medium">{email}</span>
              </p>
            </div>

            {/* Error Alert */}
            {error && (
              <Alert variant="destructive" className="mb-6 bg-red-900/20 border-red-800">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}

            {/* Code Input */}
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-200">
                  Enter 6-digit code
                </label>
                <InputOTP
                  maxLength={6}
                  value={code}
                  onChange={setCode}
                  disabled={isLoading}
                  className="flex justify-center gap-2"
                />
              </div>

              <Button
                onClick={handleVerifyEmail}
                disabled={isLoading || code.length !== 6}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Spinner className="mr-2 h-4 w-4" />
                    Verifying...
                  </>
                ) : (
                  'Verify Email'
                )}
              </Button>

              {/* Resend Code */}
              <div className="text-center">
                <p className="text-sm text-slate-400 mb-3">Didn't receive a code?</p>
                <Button
                  variant="outline"
                  onClick={handleResendCode}
                  disabled={isResending || !canResend}
                  className="w-full border-slate-600 text-slate-200 hover:bg-slate-700/50 bg-transparent"
                >
                  {isResending ? (
                    <>
                      <Spinner className="mr-2 h-4 w-4" />
                      Sending...
                    </>
                  ) : canResend ? (
                    'Resend Code'
                  ) : (
                    `Resend in ${resendCountdown}s`
                  )}
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* Footer Info */}
        <p className="text-center text-slate-500 text-xs mt-6">
          © 2024 Fleet Management System. All rights reserved.
        </p>
      </div>
    </div>
  );
}
