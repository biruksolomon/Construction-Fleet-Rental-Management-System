'use client';

import React from 'react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/lib/context/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';
import { AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { login, loadAuthContext } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (!formData.email || !formData.password) {
        throw new Error('Please fill in all fields');
      }

      const response = await login(formData.email, formData.password);

      // Token is now set in localStorage by login()
      // Wait a moment to ensure token is available, then load auth context
      await new Promise(resolve => setTimeout(resolve, 100));

      try {
        await loadAuthContext();
      } catch (contextError) {
        console.warn('Failed to load auth context, continuing anyway:', contextError);
        // Continue even if context fails to load - token is valid
      }

      router.push('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed. Please try again.');
      setIsLoading(false);
    }
  };

  return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="border border-slate-700 bg-slate-800/50 backdrop-blur-xl shadow-2xl">
            <div className="p-8">
              <div className="mb-8 text-center">
                <h1 className="text-3xl font-bold text-white mb-2">Fleet Manager</h1>
                <p className="text-slate-400">Welcome back</p>
              </div>

              {error && (
                  <Alert variant="destructive" className="mb-6 bg-red-900/20 border-red-800">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-red-200">{error}</AlertDescription>
                  </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-200">
                    Email
                  </Label>
                  <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-slate-200">
                    Password
                  </Label>
                  <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
                  />
                </div>

                <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors"
                >
                  {isLoading ? (
                      <>
                        <Spinner className="mr-2 h-4 w-4" />
                        Signing in...
                      </>
                  ) : (
                      'Sign In'
                  )}
                </Button>
              </form>

              <div className="mt-6 space-y-3 text-center text-sm text-slate-400">
                <div>
                  <Link href="/auth/forgot-password" className="text-blue-400 hover:text-blue-300">
                    Forgot your password?
                  </Link>
                </div>
                <div>
                  Don't have an account?{' '}
                  <Link href="/auth/register" className="text-blue-400 hover:text-blue-300">
                    Sign up
                  </Link>
                </div>
              </div>
            </div>
          </Card>

          <p className="text-center text-slate-500 text-xs mt-6">
            © 2024 Fleet Management System. All rights reserved.
          </p>
        </div>
      </div>
  );
}
