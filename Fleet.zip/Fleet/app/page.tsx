'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/context/auth-context';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Truck, MapPin, Zap, BarChart3, Shield, Users } from 'lucide-react';

export default function Home() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      router.push('/dashboard');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Spinner className="h-8 w-8 mx-auto mb-4" />
          <p className="text-slate-300">Loading...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="px-8 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
            <Truck className="h-6 w-6" />
          </div>
          <span className="text-xl font-bold">Fleet Manager</span>
        </div>
        <div className="flex gap-4">
          <Link href="/auth/login">
            <Button variant="ghost" className="text-slate-200 hover:text-white hover:bg-slate-700/50">
              Sign In
            </Button>
          </Link>
          <Link href="/auth/register">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-8 py-20 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          Professional Fleet Management
          <br />
          <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Made Simple
          </span>
        </h1>
        <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
          Manage vehicles, drivers, and operations with real-time tracking, maintenance scheduling, and comprehensive analytics.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/auth/register">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
              Start Free Trial
            </Button>
          </Link>
          <Button
            size="lg"
            variant="outline"
            className="border-slate-600 text-slate-200 hover:bg-slate-700/50 px-8 py-6 text-lg bg-transparent"
          >
            Watch Demo
          </Button>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-6xl mx-auto px-8 py-20">
        <h2 className="text-4xl font-bold text-center mb-16">Powerful Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <MapPin className="h-8 w-8" />,
              title: 'Real-Time Tracking',
              description: 'Track your fleet in real-time with GPS monitoring and route optimization',
            },
            {
              icon: <Zap className="h-8 w-8" />,
              title: 'Fast & Reliable',
              description: 'Lightning-fast performance with 99.9% uptime guarantee',
            },
            {
              icon: <BarChart3 className="h-8 w-8" />,
              title: 'Advanced Analytics',
              description: 'Gain insights with comprehensive reports and analytics dashboards',
            },
            {
              icon: <Shield className="h-8 w-8" />,
              title: 'Enterprise Security',
              description: 'Bank-level security with encryption and compliance certifications',
            },
            {
              icon: <Users className="h-8 w-8" />,
              title: 'Team Collaboration',
              description: 'Easy role management and team collaboration tools',
            },
            {
              icon: <Truck className="h-8 w-8" />,
              title: 'Fleet Management',
              description: 'Complete vehicle maintenance and asset management',
            },
          ].map((feature, index) => (
            <div
              key={index}
              className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-lg p-6 hover:border-blue-500/50 transition-colors"
            >
              <div className="text-blue-400 mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section className="max-w-6xl mx-auto px-8 py-20">
        <h2 className="text-4xl font-bold text-center mb-16">Simple Pricing</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { name: 'BASIC', price: '$99', vehicles: 10, features: ['GPS Tracking', 'Fuel Tracking'] },
            { name: 'STANDARD', price: '$299', vehicles: 50, features: ['All Basic', 'Maintenance', 'Mobile App'], highlight: true },
            { name: 'PREMIUM', price: '$799', vehicles: 200, features: ['All Standard', 'Payroll', 'Priority Support'] },
            { name: 'ENTERPRISE', price: 'Custom', vehicles: 'Unlimited', features: ['All Features', 'Dedicated Support'] },
          ].map((plan, index) => (
            <div
              key={index}
              className={`rounded-lg p-6 transition-all ${
                plan.highlight
                  ? 'bg-gradient-to-b from-blue-600 to-blue-700 border border-blue-500 scale-105'
                  : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
              }`}
            >
              <h3 className="text-lg font-bold mb-2">{plan.name}</h3>
              <p className="text-3xl font-bold mb-1">{plan.price}</p>
              <p className="text-slate-400 text-sm mb-4">/month</p>
              <p className="text-sm mb-4 font-medium">Up to {plan.vehicles} vehicles</p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="text-sm text-slate-300">
                    ✓ {feature}
                  </li>
                ))}
              </ul>
              <Button
                className={`w-full ${
                  plan.highlight
                    ? 'bg-white text-blue-600 hover:bg-slate-100'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                Choose Plan
              </Button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-4xl mx-auto px-8 py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Ready to streamline your fleet?</h2>
        <p className="text-xl text-slate-300 mb-8">
          Join thousands of companies managing their fleets efficiently.
        </p>
        <Link href="/auth/register">
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
            Start Your Free Trial Today
          </Button>
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 px-8 py-12">
        <div className="max-w-6xl mx-auto grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Truck className="h-6 w-6" />
              <span className="font-bold">Fleet Manager</span>
            </div>
            <p className="text-slate-400 text-sm">Professional fleet management for modern businesses.</p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Product</h4>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-white">Features</a></li>
              <li><a href="#" className="hover:text-white">Pricing</a></li>
              <li><a href="#" className="hover:text-white">Security</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-white">About</a></li>
              <li><a href="#" className="hover:text-white">Blog</a></li>
              <li><a href="#" className="hover:text-white">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-white">Privacy</a></li>
              <li><a href="#" className="hover:text-white">Terms</a></li>
              <li><a href="#" className="hover:text-white">Cookies</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400 text-sm">
          <p>&copy; 2024 Fleet Management System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
